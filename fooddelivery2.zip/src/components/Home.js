import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
//import Carousel from 'react-bootstrap/Carousel';
import Button from 'react-bootstrap/Button';
//import CardGroup from 'react-bootstrap/CardGroup';
import NavigationBar from './NavBar';
import Card from 'react-bootstrap/Card';
//import Caraousel from './caraousel';
import images from "./images";
import ImageSlider from "./ImageSlider";
export default class Home extends Component {
  render() {
    return (
      <>
      <NavigationBar />
      <ImageSlider images={images}/>
    <div style={{display: 'flex',margin:'70px'}}>
    <Card style={{ display:'flex',width: '15rem' ,margin:'30px'}}>
      <Card.Img variant="top" src="https://b.zmtcdn.com/data/pictures/9/19570539/d7670e70e86ebafdc82b9461eebf854e.jpg?output-format=webp" width='20px' height='100px'/>
      <Card.Body>
        <Card.Title>MY KHANA</Card.Title>
        <Card.Text>
        ★ 3.9 (500+) • 31 mins<br></br>
        Arabian, North Indian<br></br>
        Kormangala • 1.1 km
        </Card.Text>
        <Button variant="primary">Visit the Restraunt</Button>
      </Card.Body>
    </Card>
    
    <Card style={{direction:"flex",width: '15rem' ,margin:'30px'}}>
      <Card.Img variant="top" src="https://b.zmtcdn.com/data/pictures/9/19570539/d7670e70e86ebafdc82b9461eebf854e.jpg?output-format=webp" width='20px' height='100px' />
      <Card.Body>
        <Card.Title>Punjabi Nawabi</Card.Title>
        <Card.Text>
        ★ 3.7 (500+) • 34 mins<br></br>
        Punjabi, North Indian<br></br>
        Kormangala • 2.4 km
        </Card.Text>
        <Button variant="primary">Visit the Restraunt</Button>
      </Card.Body>
    </Card>
    <Card style={{ width: '15rem' ,margin:'30px'}}>
      <Card.Img variant="top" src="https://b.zmtcdn.com/data/pictures/9/19570539/d7670e70e86ebafdc82b9461eebf854e.jpg?output-format=webp" width='20px' height='100px' />
      <Card.Body>
        <Card.Title>NARMADA</Card.Title>
        <Card.Text>
        ★ 4.5 (500+) • 30 mins<br></br>
        Biryani, Andhra, South Indian<br></br>
        Kormangala • 1.8 km
        </Card.Text>
        <Button variant="primary">Visit the Restraunt</Button>
      </Card.Body>
    </Card>
    <Card style={{ width: '15rem' ,margin:'30px'}}>
      <Card.Img variant="top" src="https://b.zmtcdn.com/data/pictures/9/19570539/d7670e70e86ebafdc82b9461eebf854e.jpg?output-format=webp" width='20px' height='100px' />
      <Card.Body>
        <Card.Title>Madeena Hotel</Card.Title>
        <Card.Text>
        ★ 4.1 (1K+) • 29 mins<br></br>
        Indian, Biryani, North Indian<br></br>
        Kormangala • 1.5 km
        </Card.Text>
        <Button variant="primary">Visit the Restraunt</Button>
      </Card.Body>
    </Card>
    </div>
    <br></br>
    <div style={{display: 'flex',margin:'70px'}}>
    <Card style={{ display:'flex',width: '15rem' ,margin:'30px'}}>
      <Card.Img variant="top" src="https://b.zmtcdn.com/data/pictures/9/19570539/d7670e70e86ebafdc82b9461eebf854e.jpg?output-format=webp" width='20px' height='100px'/>
      <Card.Body>
        <Card.Title>MY KHANA</Card.Title>
        <Card.Text>
        ★ 3.9 (500+) • 31 mins<br></br>
        Arabian, North Indian<br></br>
        Kormangala • 1.1 km
        </Card.Text>
        <Button variant="primary">Visit the Restraunt</Button>
      </Card.Body>
    </Card>
    
    <Card style={{direction:"flex",width: '15rem' ,margin:'30px'}}>
      <Card.Img variant="top" src="https://b.zmtcdn.com/data/pictures/9/19570539/d7670e70e86ebafdc82b9461eebf854e.jpg?output-format=webp" width='20px' height='100px' />
      <Card.Body>
        <Card.Title>Punjabi Nawabi</Card.Title>
        <Card.Text>
        ★ 3.7 (500+) • 34 mins<br></br>
        Punjabi, North Indian<br></br>
        Kormangala • 2.4 km
        </Card.Text>
        <Button variant="primary">Visit the Restraunt</Button>
      </Card.Body>
    </Card>
    <Card style={{ width: '15rem' ,margin:'30px'}}>
      <Card.Img variant="top" src="https://b.zmtcdn.com/data/pictures/9/19570539/d7670e70e86ebafdc82b9461eebf854e.jpg?output-format=webp" width='20px' height='100px' />
      <Card.Body>
        <Card.Title>NARMADA</Card.Title>
        <Card.Text>
        ★ 4.5 (500+) • 30 mins<br></br>
        Biryani, Andhra, South Indian<br></br>
        Kormangala • 1.8 km
        </Card.Text>
        <Button variant="primary">Visit the Restraunt</Button>
      </Card.Body>
    </Card>
    <Card style={{ width: '15rem' ,margin:'30px'}}>
      <Card.Img variant="top" src="https://b.zmtcdn.com/data/pictures/9/19570539/d7670e70e86ebafdc82b9461eebf854e.jpg?output-format=webp" width='20px' height='100px' />
      <Card.Body>
        <Card.Title>Madeena Hotel</Card.Title>
        <Card.Text>
        ★ 4.1 (1K+) • 29 mins<br></br>
        Indian, Biryani, North Indian<br></br>
        Kormangala • 1.5 km
        </Card.Text>
        <Button variant="primary">Visit the Restraunt</Button>
      </Card.Body>
    </Card>
    </div>
    </>
    );
  }
}
