const images = [{
    id: 1,
    src: "https://www.connoisseurusveg.com/wp-content/uploads/2017/06/portobello-mushroom-hot-dogs.jpg",
    alt: "Image 1"
},
{
    id: 2,
    src: "https://b.zmtcdn.com/data/pictures/7/18896837/9bfc04732beb60e473f1833848447d5f.jpg?output-format=webp",
    alt: "Image 2 "
},
{
    id: 3,
    src: "https://b.zmtcdn.com/data/dish_photos/256/26af11a74ea045de9df8d93bf72af256.jpg?output-format=webp",
    alt: "Image 3"
}

];
export default images;