import React, { Component } from 'react';
import NavigationBar from './InitialNavBar';
class Welcome extends Component {
  render() {
    return (
        <div><NavigationBar />
        Welcome to our Food Delivery App</div>
    );
  }
}

export default Welcome;
