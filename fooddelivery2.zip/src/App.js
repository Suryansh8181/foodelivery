import React from 'react';
import './App.css';
import Welcome from './components/Welcome';
import Home from './components/Home';
import Profile from './components/Profile';
import Login from "./components/user/login";
import {BrowserRouter,Route,Routes} from 'react-router-dom';
import Register from './components/user/Register';
export const itemContext = React.createContext();

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Welcome></Welcome>}></Route>
        <Route path="/home" element={<Home></Home>}></Route>
        <Route path="/profile" element={<Profile></Profile>}></Route>
        <Route path="/login" element={<Login></Login>} />
        <Route path="/register" element={<Register/>} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
